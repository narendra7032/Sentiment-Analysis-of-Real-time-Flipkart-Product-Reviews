
import streamlit as st
import joblib
import re, string

model = joblib.load("models/sentiment_model.pkl")
vectorizer = joblib.load("models/vectorizer.pkl")

def clean_text(text):
    text = text.lower()
    text = re.sub(f"[{string.punctuation}]", "", text)
    return text

st.title("Flipkart Review Sentiment Analysis")

review = st.text_area("Enter your review")

if st.button("Analyze Sentiment"):
    cleaned = clean_text(review)
    vector = vectorizer.transform([cleaned])
    pred = model.predict(vector)[0]
    if pred == 1:
        st.success("Positive Review 😊")
    else:
        st.error("Negative Review 😞")
