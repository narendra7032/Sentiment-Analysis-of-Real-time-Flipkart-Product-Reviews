
Sentiment Analysis of Real-time Flipkart Product Reviews

Steps to run:
1. Place the provided Flipkart CSV file inside data/ folder as reviews.csv
2. Create virtual environment
3. pip install -r requirements.txt
4. Run training: python train_model.py
5. Run app: streamlit run app/app.py
